import React, { Component } from 'react';

class ErrorPage extends Component {
  render() {
    return (
        <div>
          <h2>ErrorPage</h2>
        </div>
    );
  }
}

export default ErrorPage;